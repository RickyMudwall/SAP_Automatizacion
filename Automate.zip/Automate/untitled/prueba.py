import subprocess

# Reemplaza 'allure' con la ruta completa al ejecutable de Allure en tu sistema si es necesario
comando_allure = 'allure serve my_allure'

# Ejecuta el comando Allure desde Python
try:
    resultado = subprocess.run(comando_allure, shell=True, check=True, text=True)
except subprocess.CalledProcessError as e:
    print(f"Error al ejecutar Allure: {e}")