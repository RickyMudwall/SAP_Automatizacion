from behave import given, when, then
from base_steps import BaseSteps
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
inst = BaseSteps()
carpeta_imagenes_home = "prueba"

class MySteps:
    @given('se selecciona el icono windows')
    def step_impl(context):
        inst.clickelement(carpeta_imagenes_home, "win.png", 1)

    @when('se selecciona el icono configuracion')
    def step_impl(context):
        inst.clickelement(carpeta_imagenes_home, "config.png", 2)

    @then('se selecciona la opcion personalizacion')
    def step_impl(context):
        inst.clickelement(carpeta_imagenes_home, "personalizar.png", 2)

    @then('cierre ventana')
    def step_impl(context):
        inst.sendkeys('alt', 'f4')


